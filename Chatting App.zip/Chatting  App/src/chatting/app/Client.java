
package chatting.app;
import static chatting.app.Server.dout;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.util.*;
import java.text.*;
import java.net.*;
import java.io.*;

public class Client  implements ActionListener{
    
    JTextField text;
    static JPanel a1;
    static Box vertical = Box.createVerticalBox();
    static DataOutputStream dout;
    static JFrame f = new JFrame();
    
    Client(){
        f.setLayout(null);
        
        JPanel p1 = new JPanel();
        p1.setBackground(new Color(0, 128, 255));
        p1.setBounds(0,0,450,70);
        p1.setLayout(null);
        f.add(p1);
        
        ImageIcon img1 = new ImageIcon(getClass().getResource("/icons/3.png"));
        Image img2 = img1.getImage().getScaledInstance(25, 25, Image.SCALE_DEFAULT);
        ImageIcon img3 = new ImageIcon(img2);
        JLabel back = new JLabel(img3);
        back.setBounds(5,20,25,25);
        p1.add(back);
        back.addMouseListener(new MouseAdapter(){
            public void mouseClicked(MouseEvent ae){
                System.exit(0);
            }
        });
        
        ImageIcon img4 = new ImageIcon(getClass().getResource("/icons/2.png"));
        Image img5 = img4.getImage().getScaledInstance(50, 50, Image.SCALE_DEFAULT);
        ImageIcon img6 = new ImageIcon(img5);
        JLabel profile = new JLabel(img6);
        profile.setBounds(40,10,50,50);
        p1.add(profile);
        
        
        
        ImageIcon img7 = new ImageIcon(getClass().getResource("/icons/video.png"));
        Image img8 = img7.getImage().getScaledInstance(30, 30, Image.SCALE_DEFAULT);
        ImageIcon img9 = new ImageIcon(img8);
        JLabel video = new JLabel(img9);
        video.setBounds(300,20,30,30);
        p1.add(video);
                
        
        
        ImageIcon img10 = new ImageIcon(getClass().getResource("/icons/phone.png"));
        Image img11 = img10.getImage().getScaledInstance(35, 30, Image.SCALE_DEFAULT);
        ImageIcon img12 = new ImageIcon(img11);
        JLabel phone = new JLabel(img12);
        phone.setBounds(360,20,35,30);
        p1.add(phone);
        
        
        
        ImageIcon img13 = new ImageIcon(getClass().getResource("/icons/3icon.png"));
        Image img14 = img13.getImage().getScaledInstance(10, 25, Image.SCALE_DEFAULT);
        ImageIcon img15 = new ImageIcon(img14);
        JLabel moreOp = new JLabel(img15);
        moreOp.setBounds(420,20,10,25);
        p1.add(moreOp);
        
        
        JLabel name = new JLabel("Steve");
        name.setBounds(110, 15, 100, 18);
        name.setForeground(Color.WHITE);
        name.setFont(new Font("SAN_SERIF", Font.BOLD, 18));
        p1.add(name);
        
        
        JLabel status = new JLabel("Active Now");
        status.setBounds(110, 35, 100, 18);
        status.setForeground(Color.WHITE);
        status.setFont(new Font("SAN_SERIF", Font.BOLD, 10));
        p1.add(status);
        
        
        
        a1 = new JPanel();
        a1.setBounds(5,75,440,570);
        a1.setBackground(new Color(204,229,255));
        f.add(a1);
        
        
        
        text = new JTextField();
        text.setBounds(5,655,310,40);
        text.setFont(new Font("SAN_SERIF", Font.PLAIN, 16));
        f.add(text);
        
        
        JButton send = new JButton("Send");
        send.setBounds(320, 655, 123, 40);
        send.setBackground(new Color(0, 128, 255));
        send.setForeground(Color.white);
        send.setFont(new Font("SAN_SERIF", Font.PLAIN, 16));
        send.addActionListener(this);
        f.add(send);
        
        
        f.setSize(450, 700);
        f.setLocation(800, 40);
        f.setUndecorated(true);
        f.getContentPane().setBackground(new Color(153, 204, 255));
        
        f.setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae){
       try{
            String out = text.getText();

        JPanel p2 = formatLabel(out);
   
        
        a1.setLayout(new BorderLayout());
        
        JPanel right = new JPanel(new BorderLayout());
        right.add(p2, BorderLayout.LINE_END);
        vertical.add(right);
        vertical.add(Box.createVerticalStrut(15));
        
        a1.add(vertical, BorderLayout.PAGE_START);
        
        dout.writeUTF(out);
        
        text.setText("");
        
        f.repaint();
        f.invalidate();
        f.validate();
       }catch(Exception e){
           e.printStackTrace();
       }
    }
    
    public static JPanel formatLabel(String out){
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        JLabel output = new JLabel("<html><p style=\"width: 150px\">" + out + "</p></html>");
        output.setFont(new Font("Tahoma", Font.PLAIN, 16));
        output.setForeground(Color.white);
        output.setBackground(new Color(0, 128, 255));
        output.setOpaque(true);
        output.setBorder(new EmptyBorder(15, 15, 15, 50));
        
        
        panel.add(output);
        
        
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
        JLabel time = new JLabel();
        time.setText(sdf.format(cal.getTime()));
        panel.add(time);
        
        return panel;
    }
    
    
    public static void main(String[] args){
        new Client();
        
        try{
            Socket s = new Socket("127.0.0.1", 6000);
            DataInputStream din = new DataInputStream(s.getInputStream());
            dout = new DataOutputStream(s.getOutputStream());
            
            while(true){
                a1.setLayout(new BorderLayout());
                String msg = din.readUTF();
                JPanel panel = formatLabel(msg);

                JPanel left = new JPanel(new BorderLayout());
                left.add(panel, BorderLayout.LINE_START);
                vertical.add(left);
                
                vertical.add(Box.createVerticalStrut(15));
                a1.add(vertical, BorderLayout.PAGE_START);
                
                f.validate();
            }
                
        }catch(Exception e){
            e.printStackTrace();
        }
        
    }
}
